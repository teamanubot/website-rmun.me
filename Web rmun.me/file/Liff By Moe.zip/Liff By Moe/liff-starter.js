window.onload = function (e) {
  liff.init(function (data) {
    initializeApp(data);
  });
};

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

function initializeApp(data) {
  var queryDict = {};
  location.search.substr(1).split("&").forEach(function(item) {queryDict[item.split("=")[0]] = item.split("=")[1]});
  type = getParameterByName('type');
  text = getParameterByName('text');
  url = getParameterByName('url');
  if (type == "beta" && text !== "undefined") {
    document.getElementById("message").textContent = 'Loading....';
    liff.sendMessages([
      {
          "type": "text",
          "text": text
      }
    ]);
    document.getElementById("message").textContent = 'Success';
    liff.closeWindow();
  } else if (type == "beta" && url !== "undefined") {
    document.getElementById("message").textContent = 'Loading....';
    liff.sendMessages([
      {
        "type": "template",
        "altText": "MEMEK",
        "template": {
            "type": "image_carousel",
            "columns": [
                {
                  "imageUrl": "https://raw.githubusercontent.com/tangxiadi/Google-Hestia-Anime/master/Anime/hestia-home.gif",
                  "action": {
                    "type": "uri",
                    "uri": url
                  }
                }
            ]
        }
      }
    ]);
    document.getElementById("message").textContent = 'Success';
    liff.closeWindow();
  }
}
